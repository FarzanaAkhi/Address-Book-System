
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/bootstrap-confirmation.js"></script>
    <script src="js/script.js"></script>
  </body>
</html>
