<?php
  session_start();
  require '../method/dbcon.php';
  $conn = dbcon();
  // if (isset($_SESSION['adminid'])) {
  //   header('location:add.php');
  // }

  $error = "";
  if (isset($_POST['submit'])) {
    $adminid = mysqli_real_escape_string($conn, $_POST['id']);
    $password = mysqli_real_escape_string($conn,$_POST['pass']);

    $query = "SELECT * FROM admin WHERE id='$adminid' AND pass = '$password'";
    $sql = mysqli_query($conn,$query);

    if($row = $sql->fetch_assoc()) {
      if ($adminid==$row['id'] && $password==$row['pass']) {
        $_SESSION['admin'] = $row['id'];
        header('location: add.php');
        exit();
      }
      else {
        $error = "Invalid username password";
      }
    }
  }
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Admin login</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    <div class="container text-center admin-login">
      <h3>Welcome to admin panel</h3>
      <div class="form">
        <label><?php echo $error; ?></label>
        <form action="index.php" method="post">
          <div class="form-group">
            <input type="text" name="id" placeholder="Adminid" class="form-control">
          </div>
          <div class="form-group">
            <input type="password" name="pass" placeholder="password" class="form-control">
          </div>
          <button type="submit" name="submit" class="btn btn-success">Login</button>
        </form>
      </div>
    </div>

  </body>
</html>
