<?php
  session_start();
  include 'header.php';
  require '../method/dbcon.php';
  $conn = dbcon();
  if (!isset($_SESSION['admin'])) {
    header('location:index.php');
    die();
  }

   if (isset($_GET['id'])){
    $_SESSION['userid'] = $_GET['id'];;
   }
   echo $_SESSION['user'];

  $msg = "";
  if (isset($_POST['submit'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn,$_POST['pass']);
    $query = "UPDATE user SET name='$name',email='$email',username='$username' pass='$password' WHERE id = {$_SESSION['user']}";
    $sql = mysqli_query($conn,$query);
    if ($sql) {
      $msg = "Successfully edited";
    }
    else {
      $msg = "Something going wrong";
    }
  }
?>
 <style>
   .form-control{
     width: 100%;
   }
   .msg h3{
     color: #27ae60;
   }
 </style>
 <section id="add">
   <div class="container">
     <div class="heading text-center">
       <h3>Edit User</h3>
     </div>
     <div class="msg text-center">
       <h3><?php echo $msg; ?></h3>
     </div>
     <div class="form">
       <?php
       if (isset($_GET['id'])) {
         $fid = $_GET['id'];
         $sql = "SELECT * FROM user";
         $result = mysqli_query($conn,$sql);
         $row = mysqli_fetch_array($result);
        ?>
       <form action="edit.php" method="post">
         <div class="form-group">
           <label>Name:</label>
           <input type="text" name="name" placeholder="name" id="name" class="form-control" value="<?php echo $row['name']; ?>">
         </div>
         <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" class="form-control" id="email" placeholder="Enter email" name="email"  value="<?php echo $row['email']; ?>">
         </div>
          <div class="form-group">
            <label for="email">username</label>
            <input type="text" class="form-control" id="email" placeholder="username" name="username"  value="<?php echo $row['username']; ?>">
          </div>
          <div class="form-group">
             <label for="pass">Password</label>
             <input type="password" class="form-control" id="pass" placeholder="Enter password" name="pass"  value="<?php echo $row['pass']; ?>">
          </div>
          <button type="submit" name="submit" class="btn btn-success">Edit</button>
       </form>
     <?php }?>
     </div>
   </div>
 </section>


 <?php
   include 'footer.php';
  ?>
