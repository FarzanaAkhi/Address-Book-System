<?php
  session_start();
  include 'header.php';
  require '../method/dbcon.php';
  $conn = dbcon();
  if (!isset($_SESSION['admin'])) {
    header('location:index.php');
    die();
  }

  $msg = "";
  if (isset($_POST['submit'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn,$_POST['pass']);

    $query = "INSERT INTO `user`(`name`, `email`, `username`, `pass`)
    VALUES ('$name','$email','$username','$password')";
    $sql = mysqli_query($conn,$query);
    if ($sql) {
      $msg = "Successfully added a member";
    }
    else {
      $msg = "Something going wrong";
    }
  }
?>
 <style>
   .form-control{
     width: 100%;
   }
   .msg h3{
     color: #27ae60;
   }
 </style>
 <section id="add">
   <div class="container">
     <div class="heading text-center">
       <h3>Add Users</h3>
     </div>
     <div class="msg text-center">
       <h3><?php echo $msg; ?></h3>
     </div>
     <div class="form">
       <form action="add.php" method="post">
         <div class="form-group">
           <label>Name:</label>
           <input type="text" name="name" placeholder="name" id="name" class="form-control">
         </div>
         <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
         </div>
          <div class="form-group">
            <label for="email">username</label>
            <input type="text" class="form-control" id="email" placeholder="username" name="username">
          </div>
          <div class="form-group">
             <label for="pass">Password</label>
             <input type="password" class="form-control" id="pass" placeholder="Enter password" name="pass">
          </div>
          <button type="submit" name="submit" class="btn btn-success">Add Users</button>
       </form>
     </div>
   </div>
 </section>


 <?php
   include 'footer.php';
  ?>
