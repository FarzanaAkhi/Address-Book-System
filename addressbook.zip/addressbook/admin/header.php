<?php
   if (!isset($_SESSION['admin'])) {
     header('location: index.php');
   }
   if (isset($_POST['logout'])) {
     session_start();
     session_unset();
     session_destroy();
     header('location:index.php');
   }
 ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Manage Faculty</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
  </head>
  <style>
.total-users{
  margin: 0 auto;
}
.total-users h3{
  padding: 30px;
  background: #AED581;
  color: #F9FBE7;
}
.btn-delete{
  background: transparent;
  outline: none;
  border: none;
  color: #e74c3c;
  font-size: 20px;
  transition: .3s;
}
.btn-delete i:hover{
  color: red;
}
.form-control{
  width: 20%;
}
.delete-messege{
  color: green;
}
thead tr th{
  color: #D32F2F;
  font-size: 16px;
}
</style>
  <body>
    <section id="header">
      <nav class="navbar navbar-default">
        <div class="container-fluid">
          <!-- Brand and toggle get grouped for better mobile display -->
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="add.php">Address Book</a>
            <!-- <a class="navbar-brand" href="#"><i class="flaticon-facebook-messenger-logo"></i></a> -->
          </div>

          <!-- Collect the nav links, forms, and other content for toggling -->
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
              <li><a href="add.php">Home</a></li>
              <li><a href="add.php"><i class="fa fa-user-plus" aria-hidden="true"></i> Add Users</a></li>
              <li><a href="delete.php"><i class="fa fa-trash" aria-hidden="true"></i> Delete Users</a></li>
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $_SESSION['admin']; ?><span class="caret"></span></a>
                <ul class="dropdown-menu text-center">
                  <li class="text-center">
                    <form action="header.php" method="post">
                      <button class="btn btn-info logout" type="submit" name="logout">Logout</button>
                    </form>
                  </li>
                </ul>
              </li>
            </ul>
          </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
      </nav>
    </section>
