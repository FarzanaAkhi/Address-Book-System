<?php
    function dbcon(){
     $conn = mysqli_connect('localhost','root','','address');
     return $conn;
    }
 ?>
