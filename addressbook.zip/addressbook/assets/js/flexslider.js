$(window).load(function () {
                            $('.testi-slider').flexslider({
                            animation: "slide",
                            controlNav: false,
                            directionNav: true,
                            item:1,
                        });
                    });